import { Command } from "../../lib/structures/Command.js";
import type Args from "../../lib/structures/Args.js";
import type Context from "../../lib/structures/Context.js";
import type { GuildConfigOptions } from "../../lib/utils/constants.js";
import { ApplyCommandOptions } from "../../lib/utils/functions.js";

@ApplyCommandOptions<Command.Options>({
  name: "Invalidatecase",
  permissions: {
    staff: true,
  },
  description: "Invalidates a punishment.",
})
export default class InvalidatecaseCommand extends Command {
  public override run = async (ctx: Context, args: Args) => {
    const id = await args.getNumberIndex(0).catch(() => null);
    if (!id) return ctx.reply("That is not an ID.");

    const infraction = await this.context.client.db.infractions.findFirst({
      where: {
        guildId: ctx.message.guild!.id,
        id,
      },
    });
    if (!infraction) return ctx.reply("That is not a valid infraction.");

    if (
      !this.checks.isHmod(
        ctx.member!,
        this.context.client.stores.get("guilds")!.get(ctx.message.guild!.id)! as GuildConfigOptions,
      ) &&
      infraction.moderatorId !== ctx.author.id
    )
      return ctx.reply("You cannot modify a punishment that was not issued by you.");

    await this.context.client.db.infractions.update({
      where: {
        guildId: ctx.message.guild!.id,
        id,
      },
      data: {
        invalid: true,
        expiresAt: null,
      },
    });
    return ctx.message.channel.send(
      `**${infraction.type}** \`(#${infraction.id})\` issued to <@${infraction.memberId}> issued by <@${infraction.moderatorId}> has been invalidated.`,
    );
  };
}
